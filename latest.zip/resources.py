msg_e_disco_no_montado = "El disco externo no se ha montado correctamente"
msg_e_disco_no_preparado = "NO SE HA REALIZADO LA COPIA!!!! El disco con el numero de serie {} no esta preparado"
msg_e_disco_no_vinculado = "no se ha podido desvincular el disco por el siguiente motivo:"
msg_e_disco_vinculado = "no se ha realizado la vinculacion el disco por el siguiente motivo:"
msg_i_luks_open = "Abriendo canal cifrado en disco {} ({}) como backup-externo"
msg_e_sync_error = "Se ha produccido un error en la sincronizacion de {}"
msg_mail_body_warn = 'La copia ha finalizado con advertencias, informe a sistemas si es necesario. <br><br> Advertencias: <br><br> {}'
msg_mail_sbj_warn = 'HAY ADVERTENCIAS. Consulte a sistemas si es necesario, antes de cambiar el disco'
msg_e_no_disco = 'No se encuentra ningun disco que contenga alguna de las series proporcionadas'
msg_w_canal_abierto = 'El canal cifrado del dispositivo {} se ha encontrado abierto de una operacion anterior, pero se ha cerrado con exito'

config_template = {'config': {
	'last_device': '',
	'vmc': True,
	'empresa': '',
	'item': '',
	'dom0': '',
	'dom0_backup': 'backup.hvm',
	'disco_interno': '',
	'discos': [],
	'email_smtp': '',
	'email_login': '',
	'email_from': '',
	'email_responsables': '',
	'smart': '',
	'luks_phrase': '',
	'luks_phrase_url': '',
	'luks_phrase_user': '',
	'luks_phrase_pass': ''},
	'tareas': []}

warnings = []
